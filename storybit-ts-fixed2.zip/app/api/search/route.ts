import { NextResponse } from 'next/server';

const BASE = 'https://www.omdbapi.com/';
const API = process.env.OMDB_API_KEY;

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get('q') || '';
  const page = searchParams.get('page') || '1';

  if (!API) {
    return NextResponse.json({ error: 'OMDB_API_KEY not set' }, { status: 500 });
  }

  const url = `${BASE}?s=${encodeURIComponent(q)}&page=${page}&apikey=${API}`;
  const res = await fetch(url);
  const data = await res.json();
  return NextResponse.json(data);
}
