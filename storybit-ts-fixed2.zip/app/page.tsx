import MovieRow from '../components/MovieRow';
import HeroBanner from '../components/HeroBanner';
import SearchBar from '../components/SearchBar';
import { fetchPopular } from '../lib/omdb';

export default async function Page() {
  const popular = await fetchPopular();
  return (
    <div className="space-y-8">
      <HeroBanner movie={popular[0]} />
      <div className="max-w-6xl mx-auto px-4">
        <SearchBar />
      </div>
      <MovieRow movies={popular} categoryTitle="Trending Picks" />
    </div>
  );
}
