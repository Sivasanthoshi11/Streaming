'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function WatchlistPage() {
  const [list, setList] = useState<any[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem('watchlist') || '[]';
      setList(JSON.parse(raw));
    } catch {
      setList([]);
    }
  }, []);

  function remove(id: string) {
    const next = list.filter((x) => x.imdbID !== id);
    setList(next);
    localStorage.setItem('watchlist', JSON.stringify(next));
  }

  if (list.length === 0) {
    return <div className="max-w-4xl mx-auto px-4 py-8">Your watchlist is empty.</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Watchlist</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {list.map((m) => (
          <div key={m.imdbID} className="border rounded p-2 bg-gray-900">
            <Link href={`/movie/${m.imdbID}`}>
              <img src={m.Poster} alt={m.Title} className="w-full h-48 object-cover rounded" />
              <h3 className="mt-2">{m.Title}</h3>
            </Link>
            <button onClick={() => remove(m.imdbID)} className="mt-2 px-3 py-1 bg-red-600 rounded">Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
}
