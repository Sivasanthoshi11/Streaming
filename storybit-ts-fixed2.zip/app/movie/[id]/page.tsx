import { fetchMovieById } from '../../../lib/omdb';
import Image from 'next/image';

export default async function MoviePage({ params }: { params: { id: string } }) {
  const movie = await fetchMovieById(params.id);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="md:flex gap-6">
        <div className="relative w-full md:w-1/3 h-96">
          {movie.Poster && movie.Poster !== 'N/A' && (
            <Image src={movie.Poster} alt={movie.Title} fill style={{ objectFit: 'cover' }} />
          )}
        </div>
        <div className="md:flex-1">
          <h1 className="text-3xl font-bold">{movie.Title}</h1>
          <p className="mt-4 text-gray-300">{movie.Plot}</p>
          <p className="mt-4 text-sm">⭐ {movie.imdbRating} • Year: {movie.Year}</p>
        </div>
      </div>
    </div>
  );
}
