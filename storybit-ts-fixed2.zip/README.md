# StoryBit (TypeScript) - OMDb version (Fixed packages)

## Quick start

1. Extract the ZIP and open the folder.
2. Create `.env.local` in the project root with:
```
OMDB_API_KEY=your_omdb_api_key_here
```
3. Install deps:
```
npm install
```
4. Run dev:
```
npm run dev
```
Open http://localhost:3000

## Features
- TypeScript + Next.js App Router
- Tailwind CSS
- OMDb search (server-side proxy)
- Watchlist saved to localStorage
- Improved UI components
