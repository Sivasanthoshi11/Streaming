'use client';
import Link from 'next/link';
import Image from 'next/image';

type Movie = {
  imdbID: string;
  Title: string;
  Poster: string;
  Year?: string;
};

export default function MovieRow({ movies, categoryTitle }: { movies: Movie[]; categoryTitle?: string }) {
  return (
    <section className="px-4">
      {categoryTitle && <h2 className="text-2xl font-semibold mb-4 max-w-6xl mx-auto px-4">{categoryTitle}</h2>}
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex gap-4 overflow-x-auto pb-4">
          {movies.map((m) => {
            const posterSrc = m.Poster && m.Poster !== 'N/A' ? m.Poster : '/placeholder-portrait.png';
            return (
              <Link key={m.imdbID} href={`/movie/${m.imdbID}`} className="min-w-[160px] shrink-0">
                <div className="relative h-[240px] w-[160px] rounded overflow-hidden shadow-md">
                  <Image src={posterSrc} alt={m.Title} width={160} height={240} style={{ objectFit: 'cover' }} />
                </div>
                <p className="text-sm mt-2 text-gray-200 max-w-[160px] line-clamp-2">{m.Title}</p>
                <p className="text-xs text-gray-400">{m.Year}</p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
