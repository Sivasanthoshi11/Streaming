'use client';
import { useState } from 'react';

export default function SearchBar() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  async function doSearch(e?: any) {
    if (e) e.preventDefault();
    if (!q) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&page=1`);
      const data = await res.json();
      setResults(data.Search || []);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mb-6">
      <form onSubmit={doSearch} className="flex gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search movies..."
          className="flex-1 p-3 rounded bg-gray-800 border border-gray-700"
        />
        <button type="submit" className="px-4 py-2 bg-red-600 rounded">Search</button>
      </form>

      <div className="mt-4">
        {loading && <p>Loading...</p>}
        {!loading && results.length > 0 && (
          <div className="flex gap-4 overflow-x-auto">
            {results.map((m: any) => (
              <a key={m.imdbID} href={`/movie/${m.imdbID}`} className="min-w-[140px]">
                <img src={m.Poster !== 'N/A' ? m.Poster : '/placeholder-portrait.png'} alt={m.Title} className="w-32 h-48 object-cover rounded" />
                <p className="text-sm mt-1">{m.Title}</p>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
