import Image from 'next/image';

export default function HeroBanner({ movie }: any) {
  if (!movie) return null;
  const poster = movie.Poster && movie.Poster !== 'N/A' ? movie.Poster : null;
  return (
    <div className="relative h-[60vh] w-full">
      {poster && <Image src={poster} alt={movie.Title} fill priority style={{ objectFit: 'cover' }} />}
      <div className="absolute bottom-8 left-8 text-white max-w-xl">
        <h1 className="text-4xl font-bold">{movie.Title}</h1>
        <p className="mt-2 line-clamp-3">{movie.Plot}</p>
      </div>
    </div>
  );
}
