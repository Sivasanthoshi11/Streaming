'use client';
import Link from 'next/link';

export default function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 bg-black/70 backdrop-blur z-50">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="text-white font-bold text-xl">StoryBit</Link>
        <nav className="text-gray-300">
          <Link href="/" className="mr-4">Home</Link>
          <Link href="/watchlist">Watchlist</Link>
        </nav>
      </div>
    </header>
  );
}
