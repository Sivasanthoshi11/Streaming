const API = process.env.OMDB_API_KEY;
const BASE = 'https://www.omdbapi.com/';

export async function fetchPopular() {
  const popular = ['tt1375666','tt0816692','tt4154756','tt0133093','tt0111161','tt0499549','tt0110912'];
  const results = [];
  for (const id of popular) {
    const res = await fetch(`${BASE}?i=${id}&apikey=${API}`);
    results.push(await res.json());
  }
  return results;
}

export async function fetchMovieById(id: string) {
  const res = await fetch(`${BASE}?i=${id}&apikey=${API}`);
  return res.json();
}
